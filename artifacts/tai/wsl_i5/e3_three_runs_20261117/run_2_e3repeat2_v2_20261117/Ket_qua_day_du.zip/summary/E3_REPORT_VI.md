# Kết quả E3 — batch INSERT và background merge

Run: e3repeat2_v2_20261117; máy wsl_i5; ClickHouse26.10.3.7; protocol mergetree-v2-e3-r1; commit 0c360382b07c584f11957782079b144cee13cb75.
Dataset 30,000,000 dòng/lượt, 12cột; 3batch×3vòng. Tổng 9,990request; mọi fingerprint khớp nguồn độc lập.
Thiết lập: K1(CounterID,EventDate), g8192, Wide, LZ4, fsync1, async0, insert1thread; merge tự nhiên.

| Batch | ACK trung vị (s) | ACK IQR(s) | Throughput trung vị (dòng/s) | Active storage trung vị(MiB) | Merge row amplification trung vị |
|---:|---:|---:|---:|---:|---:|
|10,000|358.919|44.946|83,584|498.875|4.488|
|100,000|171.929|50.458|174,491|499.763|2.483|
|1,000,000|114.270|26.591|262,536|499.949|1.000|

## Chi tiết9lượt

|Vòng|Vị trí|Batch|ACK(s)|Throughput(dòng/s)|Parts sauACK|Parts ổn định|Merge events|
|---:|---:|---:|---:|---:|---:|---:|---:|
|1|1|10,000|274.929|109,119|11|11|602|
|1|2|100,000|171.929|174,491|9|9|55|
|1|3|1,000,000|136.973|219,022|10|5|5|
|2|1|100,000|224.423|133,676|9|9|55|
|2|2|1,000,000|114.270|262,536|10|5|5|
|2|3|10,000|358.919|83,584|13|8|601|
|3|1|1,000,000|83.791|358,032|10|5|5|
|3|2|10,000|364.821|82,232|11|11|608|
|3|3|100,000|123.508|242,899|9|9|55|

## Giới hạn và truy vết

Median/Q1/Q3/IQR chỉ mô tả3lượt; không phải khoảng tin cậy hay kết luận nhân quả cho mọi hệ thống.
ACK elapsed gồm HTTP và xử lý input/journal giữa batch; không gồm tải mạng/chuyển Parquet hoặc thời gian producer gom batch.
Snapshot gần sauACK: độ trễ hoàn thành từ 0.0082s đến 0.4785s; không phải snapshot nguyên tử tạiACK.
Merge events được tính theo UUID bảng đến mốc server observation_end sau snapshot ổn định; tổngduration có thể chồng thời gian.
Ổn định được quan sát3lần cách10s, không có merge/mutation; không bảo đảm không phát sinh merge tương lai.
Active storage không gồm mọi inactive/tạm; merge row amplification là proxy đọc lại, không phải physical SSD write amplification.
Nguồn đã kiểm độc lập đủ30file; các workload counts30M khớp báo cáo Tuấn. Mẫu1M tự tạo có một số thống kê khác pilot trong Docs; chỉ dùng để kiểm tra pipeline E3. Chưa có curator hash-lock/code2e65b9d để khẳng định cùng chính xác bản khóa của máy E2.
Phầncứng/memory/kernel/Python thực tế trong environment.json; không dùng thời gian tuyệt đối đối chiếu máy Xeon.

Dữ liệu gốc trong ingest/, checks/, ddl/; summary/ chứa tóm tắt và figures/ chứa hình. Pilot không thay kết quả30M.
